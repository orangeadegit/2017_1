﻿namespace RSA
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ben = new System.Windows.Forms.RichTextBox();
            this.yi = new System.Windows.Forms.RichTextBox();
            this.solve = new System.Windows.Forms.Button();
            this.resolve = new System.Windows.Forms.Button();
            this.autoget = new System.Windows.Forms.Button();
            this.eee = new System.Windows.Forms.NumericUpDown();
            this.ddd = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.模数 = new System.Windows.Forms.Label();
            this.nnn = new System.Windows.Forms.NumericUpDown();
            this.path = new System.Windows.Forms.TextBox();
            this.open = new System.Windows.Forms.Button();
            this.file1 = new System.Windows.Forms.Button();
            this.file2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.eee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nnn)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "源码";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(500, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "译码";
            // 
            // ben
            // 
            this.ben.Location = new System.Drawing.Point(35, 68);
            this.ben.Name = "ben";
            this.ben.Size = new System.Drawing.Size(174, 211);
            this.ben.TabIndex = 1;
            this.ben.Text = "";
            // 
            // yi
            // 
            this.yi.Location = new System.Drawing.Point(423, 69);
            this.yi.Name = "yi";
            this.yi.Size = new System.Drawing.Size(172, 210);
            this.yi.TabIndex = 2;
            this.yi.Text = "";
            // 
            // solve
            // 
            this.solve.Location = new System.Drawing.Point(328, 120);
            this.solve.Name = "solve";
            this.solve.Size = new System.Drawing.Size(75, 23);
            this.solve.TabIndex = 3;
            this.solve.Text = "加密";
            this.solve.UseVisualStyleBackColor = true;
            this.solve.Click += new System.EventHandler(this.solve_Click);
            // 
            // resolve
            // 
            this.resolve.Location = new System.Drawing.Point(328, 163);
            this.resolve.Name = "resolve";
            this.resolve.Size = new System.Drawing.Size(75, 23);
            this.resolve.TabIndex = 3;
            this.resolve.Text = "解密";
            this.resolve.UseVisualStyleBackColor = true;
            this.resolve.Click += new System.EventHandler(this.resolve_Click);
            // 
            // autoget
            // 
            this.autoget.Location = new System.Drawing.Point(328, 76);
            this.autoget.Name = "autoget";
            this.autoget.Size = new System.Drawing.Size(75, 23);
            this.autoget.TabIndex = 3;
            this.autoget.Text = "生成密钥";
            this.autoget.UseVisualStyleBackColor = true;
            this.autoget.Click += new System.EventHandler(this.autoget_Click);
            // 
            // eee
            // 
            this.eee.Location = new System.Drawing.Point(248, 77);
            this.eee.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.eee.Name = "eee";
            this.eee.Size = new System.Drawing.Size(69, 21);
            this.eee.TabIndex = 4;
            // 
            // ddd
            // 
            this.ddd.Location = new System.Drawing.Point(248, 120);
            this.ddd.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ddd.Name = "ddd";
            this.ddd.Size = new System.Drawing.Size(69, 21);
            this.ddd.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(213, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "公钥";
            this.label3.Click += new System.EventHandler(this.label1_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(213, 120);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(29, 12);
            this.label.TabIndex = 0;
            this.label.Text = "密钥";
            this.label.Click += new System.EventHandler(this.label1_Click);
            // 
            // 模数
            // 
            this.模数.AutoSize = true;
            this.模数.Location = new System.Drawing.Point(213, 165);
            this.模数.Name = "模数";
            this.模数.Size = new System.Drawing.Size(29, 12);
            this.模数.TabIndex = 0;
            this.模数.Text = "公钥";
            this.模数.Click += new System.EventHandler(this.label1_Click);
            // 
            // nnn
            // 
            this.nnn.Location = new System.Drawing.Point(248, 163);
            this.nnn.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nnn.Name = "nnn";
            this.nnn.Size = new System.Drawing.Size(69, 21);
            this.nnn.TabIndex = 4;
            // 
            // path
            // 
            this.path.Location = new System.Drawing.Point(216, 202);
            this.path.Name = "path";
            this.path.Size = new System.Drawing.Size(187, 21);
            this.path.TabIndex = 5;
            // 
            // open
            // 
            this.open.Location = new System.Drawing.Point(276, 229);
            this.open.Name = "open";
            this.open.Size = new System.Drawing.Size(75, 23);
            this.open.TabIndex = 3;
            this.open.Text = "打开文件";
            this.open.UseVisualStyleBackColor = true;
            this.open.Click += new System.EventHandler(this.open_Click);
            // 
            // file1
            // 
            this.file1.Location = new System.Drawing.Point(229, 256);
            this.file1.Name = "file1";
            this.file1.Size = new System.Drawing.Size(75, 23);
            this.file1.TabIndex = 3;
            this.file1.Text = "文件加密";
            this.file1.UseVisualStyleBackColor = true;
            this.file1.Click += new System.EventHandler(this.file1_Click);
            // 
            // file2
            // 
            this.file2.Location = new System.Drawing.Point(328, 258);
            this.file2.Name = "file2";
            this.file2.Size = new System.Drawing.Size(75, 23);
            this.file2.TabIndex = 3;
            this.file2.Text = "文件解密";
            this.file2.UseVisualStyleBackColor = true;
            this.file2.Click += new System.EventHandler(this.file2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(625, 322);
            this.Controls.Add(this.path);
            this.Controls.Add(this.ddd);
            this.Controls.Add(this.nnn);
            this.Controls.Add(this.eee);
            this.Controls.Add(this.file2);
            this.Controls.Add(this.file1);
            this.Controls.Add(this.open);
            this.Controls.Add(this.autoget);
            this.Controls.Add(this.resolve);
            this.Controls.Add(this.solve);
            this.Controls.Add(this.yi);
            this.Controls.Add(this.ben);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label);
            this.Controls.Add(this.模数);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.eee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nnn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox ben;
        private System.Windows.Forms.RichTextBox yi;
        private System.Windows.Forms.Button solve;
        private System.Windows.Forms.Button resolve;
        private System.Windows.Forms.Button autoget;
        private System.Windows.Forms.NumericUpDown eee;
        private System.Windows.Forms.NumericUpDown ddd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label 模数;
        private System.Windows.Forms.NumericUpDown nnn;
        private System.Windows.Forms.TextBox path;
        private System.Windows.Forms.Button open;
        private System.Windows.Forms.Button file1;
        private System.Windows.Forms.Button file2;
    }
}

