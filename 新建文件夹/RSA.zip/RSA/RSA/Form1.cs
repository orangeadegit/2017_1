﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace RSA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string zimu_biao = "abcdefghijklmnopqrstuvwxyz";
        OpenFileDialog ofd;

        long benan_huan(long b, long[] a, long k)
        {
            long t, temp = -1;
            while (b > 0)
            {
                t = b % 2;
                temp++;
                a[temp] = t;
                b = b / 2;
            }
            return temp;
        }
        long gcd(long n, long b)
        {
            long r1 = n, r2 = b, r;
            while (r2 > 0)
            {
                r = r1 % r2;
                r1 = r2;
                r2 = r;
            }
            return r1;
        }
        long extend(long n, long b)
        {
            long q, r, r1 = n, r2 = b, t, t1 = 0, t2 = 1, i = 1;
            while (r2 > 0)
            {
                q = r1 / r2;
                r = r1 % r2;
                r1 = r2;
                r2 = r;
                t = t1 - q * t2;
                t1 = t2;
                t2 = t;
            }
            if (t1 >= 0)
                return t1 % n;
            else
            {
                while ((t1 + i * n) < 0)
                    i++;
                return t1 + i * n;
            }
        }
        long Witness(long a, long n)
        {
            long d = 1, k, r = n - 1, i, x;
            long[] b = new long[1000];
            k = benan_huan(r, b, 1000); for (i = k; i >= 0; i--)
            {
                x = d;
                d = (d * d) % n;
                if ((d == 1) && (x != 1) && (x != n - 1)) return 0;
                if (b[i] == 1) d = (d * a) % n;
            }
            if (d != 1) return 0;
            else return 1;
        } 
        long js_mod(long a, long b, long n)
        {
            long x = 0, y = 1, k, i;
            long[] s = new long[1000];
            k = benan_huan(b, s, 1000);
            for (i = k; i >= 0; i--)
            {
                x = 2 * x;
                y = (y * y) % n;
                if (s[i] == 1)
                {
                    x++;
                    y = (y * a) % n;
                }
            }
            return y;
        }
        public string jiayi(long ee, long nn, string text)
        {
            string ans = "";
            for (int i = 0; i < text.Length; i++)
                for (int j = 0; j < 26; j++) //for(j=0;j<26;j++)       
                    if (text[i] == zimu_biao[j])
                    {
                        long x = js_mod(j, ee, nn);
                        ans += String.Format("{0,7}", x.ToString());
                    }
            return ans;
        }
        public string jieyi(long dd, long nn, string text)
        {
            long[] m = new long[1000];
            long cnt = 0;
            string s = "";
            string ans = "";
            text += ' ';
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] != ' ')
                {
                    s += text[i] - '0';
                }
                else
                {
                    if (s != string.Empty)
                    {
                        m[cnt++] = long.Parse(s);
                    }
                    s = "";
                }
            }
            for (int i = 0; i < cnt; i++)
                ans += zimu_biao[(int)(js_mod(m[i], dd, nn) % 26)];
            return ans;
        }  

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void autoget_Click(object sender, EventArgs e)
        {
            long[] prime = new long[1000];
            int cnt = 0;
            for (int i = 2; i < 1000; i++)
            {
                bool can = true;
                double x = System.Math.Sqrt(i);
                for (int j = 2; j <= x; j++)
                {
                    if (i % j == 0)
                    {
                        can = false;
                        break;
                    }
                }
                if (can)
                {
                    prime[cnt++] = i;
                }
            }
            Random rm = new Random();
            long p = prime[rm.Next(0, cnt)];
            long q = prime[rm.Next(0, cnt)];
            while (p == q || p * q < 100)
            {
                p = prime[rm.Next(1, cnt)];
                q = prime[rm.Next(1, cnt)];
            }
            long ee = prime[rm.Next(0, cnt)];
            while (ee >= (p - 1) * (q - 1)) ee = prime[rm.Next(1, cnt)];
            long d = extend((p - 1) * (q - 1), ee);
            nnn.Value = p * q;
            eee.Value = ee;
            ddd.Value = d;
        }

        private void solve_Click(object sender, EventArgs e)
        {
            yi.Text = jiayi((long)eee.Value, (long)nnn.Value, ben.Text);
        }

        private void resolve_Click(object sender, EventArgs e)
        {
            ben.Text = jieyi((long)ddd.Value, (long)nnn.Value, yi.Text);
        }

        private void open_Click(object sender, EventArgs e)
        {
            ofd = new OpenFileDialog();
            ofd.Filter = "文本文件|*.txt";
            ofd.InitialDirectory = @"C:\Documents and Settings\Adyinistrator\桌面";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                path.Text = ofd.FileName;
            }
        }

        private void file1_Click(object sender, EventArgs e)
        {
            string texts = "";
            StreamReader sr = File.OpenText(ofd.FileName);
            while (sr.EndOfStream != true)
            {
                string getss = sr.ReadLine();
                texts += getss;
            }
            ben.Text = texts;
            yi.Text = jiayi((long)eee.Value, (long)nnn.Value, texts);

            SaveFileDialog file = new SaveFileDialog();
            file.Filter = "文本文件|*.txt";
            Path.GetDirectoryName(ofd.FileName);
            string savepath = Path.GetDirectoryName(ofd.FileName);
            savepath += "\\加密.txt";
            FileStream fs1 = new FileStream(savepath, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter m_streamWriter = new StreamWriter(fs1);
            m_streamWriter.Write(yi.Text);
            m_streamWriter.Close();
            sr.Close();
            string ofdpath = ofd.FileName;
            //ofd.Reset();
            if (File.Exists(ofdpath))
            {
                //如果存在则删除
                File.Delete(ofdpath);
            }
            MessageBox.Show("加密成功，已删除原文件", "OK");
        }

        private void file2_Click(object sender, EventArgs e)
        {
            string texts = "";
            StreamReader sr = File.OpenText(ofd.FileName);
            while (sr.EndOfStream != true)
            {
                string getss = sr.ReadLine();
                texts += getss;
            }
            yi.Text = texts;
            ben.Text = jieyi((long)ddd.Value, (long)nnn.Value, texts);

            SaveFileDialog file = new SaveFileDialog();
            file.Filter = "文本文件|*.txt";
            Path.GetDirectoryName(ofd.FileName);
            string savepath = Path.GetDirectoryName(ofd.FileName);
            savepath += "\\解密.txt";
            FileStream fs1 = new FileStream(savepath, FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter m_streamWriter = new StreamWriter(fs1);
            m_streamWriter.Write(ben.Text);
            m_streamWriter.Close();
            sr.Close();
            string ofdpath = ofd.FileName;
            //ofd.Reset();
            if (File.Exists(ofdpath))
            {
                //如果存在则删除
                File.Delete(ofdpath);
            }
            MessageBox.Show("解密成功，已删除原文件", "OK");
        }
    }
}



